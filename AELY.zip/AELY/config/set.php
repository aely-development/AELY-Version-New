<?php
    session_start();
    // ARQUIVO DE CONFIGURAÇÃO E CONEXÃO DO BANCO DE DADOS

    define('MYSQL_HOST', 'localhost');
    define('MYSQL_DATABASE', 'aely-bd');
    define('MYSQL_USER', 'root');
    define('MYSQL_PASS', '');

?>